package com.c2c.mygame;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
